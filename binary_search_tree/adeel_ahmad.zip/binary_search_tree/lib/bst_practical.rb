
def kth_largest(tree_node, k)
  # both operations, traversal and look up are nlog(n)
  # 2nlog(n) => nlog(n) time complexity
  kth_largest_value = tree_node.in_order_traversal(tree_node)[-k]
  tree_node.find(kth_largest_value)
end
